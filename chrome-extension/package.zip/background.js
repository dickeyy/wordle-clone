chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension Loaded')
});